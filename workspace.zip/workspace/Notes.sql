# SELECT 100 > 5;
# SELECT -15 > 15;
# SELECT 9 > -10;
# SELECT 1 > 1;
# SELECT 'a' > 'b';
# SELECT 'A' > 'a';

# SELECT 3<-10;
# SELECT-10<-9;
# SELECT 42<=42;
# SELECT 'h'<'p';
# SELECT 'Q' <= 'q';

# SELECT title, author_lname, released_year FROM books
# WHERE author_lname > 2010;

# SELECT title, author_lname, released_year FROM books
# WHERE author_lname = 'Eggers';

# SELECT title, author_lname,
# released_year FROM books
# WHERE author_lname = 'Eggers' AND
# released_year > 2010;

# SELECT 1<5 && 7=9

# SELECT -10 > -20 && 0 <= 0;
# SELECT -40 <= 0 && 10 > 40;
# SELECT 54 <= 54 && 'a' = 'A';

# SELECT * FROM books
# WHERE author_lname = 'Eggers' AND
# released_year > 2010 AND
# title LIKE '%novel%';

# Logical OR

# SELECT title, author_lname,
# released_year FROM books
# WHERE author_lname = 'Eggers' ||
# released_year > 2010;

# SELECT 40 <= 100 || -2 > 0;
# SELECT 10 > 5 || 5 = 5;
# SELECT 'a' = 5 || 3000>2000;

# SELECT title, author_lname,
# released_year, stock_quantity FROM books
# WHERE author_lname = 'Eggers' ||
# released_year > 2010 ||
# stock_quantity >100;

# Logical BETWEEN

# SELECT title, released_year FROM books
# WHERE released_year >= 2004 &&
# released_year <= 2015;

# SELECT title, released_year FROM books
# WHERE released_year BETWEEN 2004 AND 2015;

# SELECT title, released_year FROM books
# WHERE released_year NOT BETWEEN 2004 AND 2015
# ORDER BY released_year;

# SELECT CAST ('2017-05-02' AS datetime);

# SELECT name, birthdt FROM people
# WHERE birthdt BETWEEN '1980-01-01'
# AND '2000-01-01';

# SELECT name, birthdt FROM people
# WHERE birthdt BETWEEN CAST
# ('1980-01-01' AS Datetime)
# AND cast ('2000-01-01' AS Datetime);

# SELECT 
#     name, 
#     birthdt 
# FROM people
# WHERE 
#     birthdt BETWEEN CAST('1980-01-01' AS DATETIME)
#     AND CAST('2000-01-01' AS DATETIME);

SELECT title, author_lname FROM books
WHERE author_lname='Carver' OR
author_lname='Lahiri'||
author_lname='Smith';