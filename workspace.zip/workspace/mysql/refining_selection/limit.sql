# SELECT title, released_year FROM books 
# ORDER BY released_year DESC LIMIT 5;

SELECT title, released_year FROM books 
ORDER BY released_year DESC LIMIT 10,3;