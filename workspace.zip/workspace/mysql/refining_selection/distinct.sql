# SELECT distinct author_lname FROM books;

# SELECT distinct concat (author_fname,
#                         ' ',
#                         author_lname)
# FROM books;

# SELECT DISTINCT author_fname,
# author_lname FROM books;