SELECT author_fname, author_lname
FROM books ORDER BY author_lname, author_fname;