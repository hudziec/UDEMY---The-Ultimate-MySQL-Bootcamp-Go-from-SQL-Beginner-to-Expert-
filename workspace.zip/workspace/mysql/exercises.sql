# Why does my cat look at me with such hatred?

# SELECT
# reverse(
# upper(
# 'Why does my cat look at me with such hatred?'));

# SELECT
# REPLACE(
# concat('I', ' ', 'like', ' ', 'cats'),
# ' ', '-');

# SELECT
#     REPLACE(title, ' ', '->') AS title
# FROM books;

# SELECT
#     author_lname AS forwards,
#     reverse (author_lname) AS backwards
# FROM books;

# SELECT
#     upper
#     (
#         concat(author_fname, ' ', author_lname)
#     ) AS 'full name in caps'
# FROM books;

# SELECT
#     concat(
#     title, ' was released in ', released_year)
#     as blurb
# FROM books;

# SELECT
#     title,
#     CHAR_LENGTH(title) AS 'charater count' 
# FROM books;

# SELECT
#     concat(substring(title,1,10),'...') AS 'short title',
#     concat(author_lname, ',', author_fname) AS author,
#     concat(stock_quantity, ' in stock') AS quantity
# FROM books;

# CODE: 500 Users Exercises Solutions
# Solutions To 500 Users Exercises


-- Challenge 1


# SELECT 
#     DATE_FORMAT(MIN(created_at), "%M %D %Y") as earliest_date 
# FROM users;


# -- Challenge 2

# SELECT * 
# FROM   users 
# WHERE  created_at = (SELECT Min(created_at) 
#                      FROM   users); 


-- Challenge 3


# SELECT Monthname(created_at) AS month, 
#        Count(*)              AS count 
# FROM   users 
# GROUP  BY month 
# ORDER  BY count DESC; 


-- Challenge 4


# SELECT Count(*) AS yahoo_users 
# FROM   users 
# WHERE  email LIKE '%@yahoo.com'; 


-- Challenge 5


SELECT CASE 
         WHEN email LIKE '%@gmail.com' THEN 'gmail' 
         WHEN email LIKE '%@yahoo.com' THEN 'yahoo' 
         WHEN email LIKE '%@hotmail.com' THEN 'hotmail' 
         ELSE 'other' 
       end      AS provider, 
       Count(*) AS total_users 
FROM   users 
GROUP  BY provider 
ORDER  BY total_users DESC; 