CREATE TABLE users(
username VARCHAR(100),
age INT
);