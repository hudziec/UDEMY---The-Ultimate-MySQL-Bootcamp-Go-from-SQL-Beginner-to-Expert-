INSERT INTO cats(name, AGE)
VALUES('Charlie',17);

INSERT INTO cats(name, AGE)
VALUES('Connie',10);
