# SELECT
#     concat
#     (
#         substring(title,1,10),
#         '...'
#     ) AS 'short title'
# FROM books;

# SELECT
#     substring(REPLACE(title,'e','3'),1,10)
#     AS 'weird string'
# FROM books;

# SELECT concat('woof', reverse('woof'));

# SELECT concat(author_fname,
#               reverse(author_fname))
#               FROM books;

# "Eggers is 6 characters long"

# SELECT concat(author_lname, ' is ',
#               char_length(author_lname),
#              ' characters long')
#              FROM books;

# SELECT concat('MY FAVORITE BOOK IS ',
#               upper(title))
#               FROM books;

